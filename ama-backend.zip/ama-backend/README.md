# AMA backend (v1)

FastAPI service that audits an Instagram business profile and returns a plain-language
game plan: a #1 priority, a few more actions, a 7-day content plan, and the supporting numbers.

## Run
    pip install -r requirements.txt
    export APIFY_TOKEN=your_token        # only for the live endpoint
    uvicorn main:app --reload
    # open http://127.0.0.1:8000/docs

## Endpoints
- `GET /audit?handle=kortyard.in` — scrapes via Apify (apify/instagram-scraper, resultsType=details), then audits.
- `POST /audit/raw` — paste a raw Apify profile JSON; runs the same engine with no network/token. Great for testing.
- `GET /health`

## Files
- `engine.py` — pure audit logic (no I/O). `run_audit(profile) -> insights`.
- `apify_client.py` — calls the Apify actor.
- `main.py` — the API.
