"""
Thin client for Apify's official Instagram Scraper actor (apify/instagram-scraper).

We use resultsType="details", which returns one profile object per input URL,
including the `latestPosts` array — the exact shape engine.run_audit expects.

The run-sync-get-dataset-items endpoint runs the actor and returns the dataset
items in one call (fine for a single profile, which finishes in seconds).
"""
import os
import httpx

try:
    from dotenv import load_dotenv
    load_dotenv()  # reads APIFY_TOKEN from a .env file in the backend folder, if present
except ImportError:
    pass

ACTOR_ID = "apify~instagram-scraper"
BASE = f"https://api.apify.com/v2/acts/{ACTOR_ID}/run-sync-get-dataset-items"


def _profile_url(handle: str) -> str:
    handle = handle.strip().lstrip("@").rstrip("/")
    # accept either a bare handle or a full URL
    if handle.startswith("http"):
        return handle if handle.endswith("/") else handle + "/"
    return f"https://www.instagram.com/{handle}/"


async def fetch_profile(handle: str, posts_limit: int = 30,
                        token: str | None = None, timeout: float = 120.0) -> dict:
    """
    Scrape one Instagram profile + its latest posts.
    Returns the raw Apify profile object (dict), ready for engine.run_audit().
    Raises RuntimeError on auth/empty/scrape problems.
    """
    token = token or os.environ.get("APIFY_TOKEN")
    if not token:
        raise RuntimeError("APIFY_TOKEN not set. Add it to your environment or .env file.")

    run_input = {
        "directUrls": [_profile_url(handle)],
        "resultsType": "details",     # profile object incl. latestPosts
        "resultsLimit": posts_limit,  # how many recent posts to pull
        "addParentData": False,
        "searchType": "user",
        "searchLimit": 1,
    }

    async with httpx.AsyncClient(timeout=timeout) as client:
        resp = await client.post(BASE, params={"token": token}, json=run_input)

    if resp.status_code == 401:
        raise RuntimeError("Apify rejected the token (401). Check your APIFY_TOKEN.")
    if resp.status_code == 402:
        raise RuntimeError("Apify says you're out of credit (402). Top up or use the free tier.")
    resp.raise_for_status()

    items = resp.json()
    if not items:
        raise RuntimeError(f"We couldn't find a public profile for @{handle}. "
                           "Double-check the handle and try again.")
    profile = items[0]
    # friendly, specific reasons the demo can surface nicely
    if profile.get("private"):
        raise RuntimeError(f"@{handle} looks like a private account — AMA can only read public profiles.")
    if not profile.get("latestPosts"):
        raise RuntimeError(f"@{handle} doesn't have public posts we can analyze yet.")
    return profile
