"""
AMA audit engine.

One public entrypoint: run_audit(business: dict) -> dict
`business` is a single profile object from Apify's apify/instagram-scraper
(resultsType="details"), i.e. profile fields plus a `latestPosts` list.

The engine is pure (no network, no I/O) so it runs identically whether the
JSON came from a live Apify call or a pasted sample.
"""
import re
from datetime import datetime, timezone
from collections import Counter

FMT = "%Y-%m-%dT%H:%M:%S.%f%z"


def _now():
    # "today" for recency math. Override in tests if needed.
    return datetime.now(timezone.utc)


def _parse_ts(s):
    return datetime.strptime(s, FMT)


# ----------------------------- classification -----------------------------
CATEGORY_KW = {
    "Educational": ["how to", "tip", "tips", "guide", "did you know", "learn",
                    "recipe", "steps", "benefits", "why ", "what is", "mistake",
                    "avoid", "secret", "hack"],
    "Promotional": ["offer", "discount", "% off", "sale", "deal", "combo",
                    "price", "starting at", "flat ", "coupon", "limited time", "free "],
    "Behind-the-scenes": ["behind the scenes", "bts", "making of", "our team",
                          "meet the", "how we make", "process", "day in the life"],
    "Testimonial/Social proof": ["review", "testimonial", "client", "customer",
                                 "loved", "feedback", "rated", "thank you for",
                                 "happy customer", "transformation"],
    "Event/Community": ["event", "workshop", "join us", "rsvp", "live", "meetup",
                        "celebrate", "festival", "pop up", "popup"],
    "Trend/Entertainment": ["trend", "viral", "reels", "fyp", "meme", "pov",
                            "relatable", "funny", "trending"],
    "Announcement": ["announce", "launching", "now open", "introducing", "new ",
                     "coming soon", "winding down", "closing", "closed",
                     "grand opening", "we are now"],
}

CTA_PATTERNS = {
    "book": r"book now|book your|reserve|booking",
    "call": r"\bcall us\b|call now|call \+?\d",
    "dm": r"\bdm\b|dm us|dm to|message us|inbox",
    "register": r"register|sign up|sign-up|enroll",
    "link in bio": r"link in bio|bio link|check bio",
    "order": r"order now|order online|swiggy|zomato|order on",
    "visit": r"visit us|visit our|come over|drop by|see you at|swing by",
    "shop": r"shop now|buy now|grab yours|get yours|available now",
    "comment": r"comment below|comment your|tell us in the comments|drop a",
    "share": r"share this|share it|tag a friend|tag someone|tag your",
    "save": r"save this|save it for|bookmark",
}

CLOSURE_KW = ["winding down", "winding up", "closing", "closed permanently",
              "last day", "shutting", "wind down operations", "final day",
              "we are closing", "permanently closed", "our last"]


def _classify(post):
    blob = ((post.get("caption") or "") + " " +
            " ".join(post.get("hashtags") or [])).lower()
    scores = {}
    for cat, kws in CATEGORY_KW.items():
        s = sum(1 for kw in kws if kw in blob)
        if s:
            scores[cat] = s
    return max(scores, key=scores.get) if scores else "Product/Service showcase"


def _biz_noun(snapshot):
    blob = ((snapshot.get("bio") or "") + " " + (snapshot.get("category") or "") +
            " " + (snapshot.get("full_name") or "")).lower()
    table = [
        (["cafe", "coffee", "restaurant", "food", "flour", "bakery", "kitchen",
          "eatery", "brunch"], ("dish", "menu item", "food")),
        (["salon", "beauty", "hair", "makeup", "nails", "spa"],
         ("service", "look", "transformation")),
        (["skin", "derma", "clinic", "aesthetic", "wellness"],
         ("treatment", "result", "service")),
        (["photo", "studio", "shoot", "camera"],
         ("shoot", "session", "portfolio set")),
        (["fashion", "boutique", "apparel", "clothing", "wear", "atelier",
          "outfit", "jewel"], ("piece", "collection", "outfit")),
        (["event", "wedding", "decor", "host", "party", "venue"],
         ("event", "setup", "celebration")),
    ]
    for kws, nouns in table:
        if any(k in blob for k in kws):
            return nouns
    return ("offering", "service", "product")


# ----------------------------- metrics -----------------------------
def _metrics(b):
    posts = b.get("latestPosts", []) or []
    followers = b.get("followersCount") or 0
    cat = (b.get("businessCategoryName") or "").replace("None,", "").replace("None", "").strip(", ") or "Uncategorized"
    snap = {
        "username": b.get("username"),
        "full_name": b.get("fullName"),
        "category": cat,
        "followers": followers,
        "following": b.get("followsCount"),
        "total_posts": b.get("postsCount"),
        "highlights": b.get("highlightReelCount"),
        "verified": b.get("verified"),
        "bio": (b.get("biography") or "")[:160],
    }
    r = {"snapshot": snap}
    if not posts:
        r["empty"] = True
        return r

    n = len(posts)
    pct = lambda x: round(x / n * 100, 1)
    ts = sorted(_parse_ts(p["timestamp"]) for p in posts)
    span = (ts[-1] - ts[0]).days or 1
    ppw = round(n / (span / 7), 2) if span > 0 else n
    days_since = (_now() - ts[-1]).days
    if ppw >= 4: label = "Excellent"
    elif ppw >= 2.5: label = "Good"
    elif ppw >= 1: label = "Medium"
    else: label = "Low"
    if days_since > 60: label = "Dormant"
    r["consistency"] = {"posts_analyzed": n, "first": ts[0].date().isoformat(),
                        "last": ts[-1].date().isoformat(), "span_days": span,
                        "avg_per_week": ppw, "days_since_last": days_since, "label": label}

    fm = Counter(p.get("type") for p in posts)
    r["format"] = {"video_pct": pct(fm.get("Video", 0)), "image_pct": pct(fm.get("Image", 0)),
                   "carousel_pct": pct(fm.get("Sidecar", 0)), "counts": dict(fm),
                   "top": fm.most_common(1)[0][0] if fm else None}

    likes = [p.get("likesCount", 0) or 0 for p in posts]
    comments = [p.get("commentsCount", 0) or 0 for p in posts]
    avgL, avgC = sum(likes) / n, sum(comments) / n
    er = round((avgL + avgC) / followers * 100, 3) if followers else 0
    eng = sorted(posts, key=lambda p: (p.get("likesCount", 0) or 0) + (p.get("commentsCount", 0) or 0), reverse=True)
    top3 = [{"eng": (p.get("likesCount", 0) or 0) + (p.get("commentsCount", 0) or 0),
             "likes": p.get("likesCount", 0), "comments": p.get("commentsCount", 0),
             "type": p.get("type"), "caption": (p.get("caption") or "")[:60].replace("\n", " ")}
            for p in eng[:3]]
    vv = [p.get("videoViewCount") for p in posts if p.get("videoViewCount") is not None]
    r["engagement"] = {"avg_likes": round(avgL, 1), "avg_comments": round(avgC, 2),
                       "avg_eng": round(avgL + avgC, 1), "er_pct": er, "top3": top3,
                       "video": {"n": len(vv), "avg_views": round(sum(vv) / len(vv)) if vv else None,
                                 "max_views": max(vv) if vv else None, "min_views": min(vv) if vv else None}}

    cats = Counter(_classify(p) for p in posts)
    r["categories"] = {k: {"count": v, "pct": pct(v)} for k, v in cats.most_common()}

    cta_hits, cta_posts = Counter(), 0
    for p in posts:
        t = (p.get("caption") or "").lower()
        found = {name for name, pat in CTA_PATTERNS.items() if re.search(pat, t)}
        if found:
            cta_posts += 1
        for f in found:
            cta_hits[f] += 1
    cta_pct = pct(cta_posts)
    r["cta"] = {"posts": cta_posts, "pct": cta_pct,
                "types": [k for k, _ in cta_hits.most_common(4)],
                "strength": "Strong" if cta_pct >= 60 else "Moderate" if cta_pct >= 30 else "Weak"}

    real_counts = [len(p.get("hashtags") or []) for p in posts]
    zero = sum(1 for c in real_counts if c == 0)
    # keyword-stuffing = a bracketed list with multiple commas, e.g. "(best cafe, cafe near me, ...)"
    def _stuffed(text):
        return bool(re.search(r"\([^)]*,[^)]*,[^)]*\)", text) or re.search(r"\[[^\]]*,[^\]]*,[^\]]*\]", text))
    paren = sum(1 for p in posts if _stuffed(p.get("caption") or ""))
    alltags = Counter()
    for p in posts:
        for h in (p.get("hashtags") or []):
            alltags[h.lower()] += 1
    r["hashtags"] = {"avg_per_post": round(sum(real_counts) / n, 1), "zero_posts": zero,
                     "paren_stuffing_posts": paren, "top": [h for h, _ in alltags.most_common(6)],
                     "total_unique": len(alltags)}

    closure, sig = False, None
    for p in sorted(posts, key=lambda p: p["timestamp"], reverse=True)[:3]:
        t = (p.get("caption") or "").lower()
        for kw in CLOSURE_KW:
            if kw in t:
                closure, sig = True, kw
                break
        if closure:
            break
    r["lifecycle"] = {"closure_flag": closure, "signal": sig, "dormant": days_since > 60}
    return r


# ----------------------------- plain-language advice -----------------------------
def _actions(r):
    s, e, c = r["snapshot"], r["engagement"], r["consistency"]
    h, cta, lc, cats = r["hashtags"], r["cta"], r["lifecycle"], r["categories"]
    fol = s["followers"] or 1
    n0, n1, n2 = _biz_noun(s)
    A = []
    if lc["closure_flag"]:
        return [("Say a warm thank you to your customers",
                 "Your goodbye post got more love than almost anything else you've posted. Lean into that.", "Big", "15 min"),
                ("Show people how to keep buying from you",
                 "Tell your regulars where to order once you close — pop the link in every post and your bio.", "Big", "10 min"),
                ("Count down your final days",
                 "A little \"only 3 days left!\" brings people in. Post a quick reminder each day.", "Big", "10 min a day"),
                ("Share your favourite customer memories",
                 "Repost photos and tags from happy customers — it turns your closing into a celebration.", "Worth doing", "20 min")]
    if lc["dormant"]:
        A.append(("Start posting again — try 3 posts this week",
                  f"Your page has been quiet for {c['days_since_last']} days. Getting back into a regular habit is the first thing that'll help.", "Big", "30 min"))
    if cta["strength"] == "Weak":
        verb = {"dish": "Order now", "service": "Book now", "treatment": "Book a visit",
                "shoot": "DM to book", "piece": "Shop now", "event": "Enquire now"}.get(n0, "Book now")
        A.append((f'Add a clear CTA — like "{verb}" — to every post',
                  "Almost none of your posts ask people to do anything. A simple call-to-action (CTA) turns viewers into customers, and posts that ask for action tend to get more saves and comments — so your engagement rate goes up too. It costs you nothing.", "Big", "2 min a post"))
    if h["paren_stuffing_posts"] >= 3 or h["zero_posts"] >= 6:
        A.append(("Use proper hashtags — 8 to 10 with a # sign",
                  "A lot of your posts barely reach new people. You're writing keywords in brackets, but Instagram only finds you through words with a # in front. This is free attention you're leaving on the table.", "Big", "5 min a post"))
    if c["label"] in ("Low", "Medium") and not lc["dormant"]:
        A.append((f"Post about {max(3, round(c['avg_per_week']) + 2)} times a week, every week",
                  f"You post around {c['avg_per_week']} times a week now. Posting a bit more often — and regularly — keeps you in people's feeds, so more of them see you each week.", "Worth doing", "plan on Sunday"))
    miss = [k for k in ["Testimonial/Social proof", "Behind-the-scenes", "Educational"] if k not in cats]
    if miss:
        opt = {"Testimonial/Social proof": ("Share a happy customer's words",
                f"Post a screenshot or quote from a customer who loved your {n1}. People trust other customers far more than ads — and you're not doing this yet."),
               "Behind-the-scenes": ("Show what goes on behind the scenes",
                f"Give a little peek at how you make your {n0}. People love seeing the real work, and it builds trust."),
               "Educational": ("Share one quick helpful tip",
                f"Teach people one small thing about your {n2}. Helpful posts make people see you as the expert.")}[miss[0]]
        A.append((opt[0], opt[1], "Worth doing", "20 min"))
    if e["er_pct"] < 0.5 and c["avg_per_week"] >= 3:
        A.append(("Grab attention in the first second",
                  "You post a lot, but not many people react. Start your videos with something eye-catching or a question — not your logo.", "Worth doing", "rethink openers"))
    _rr = ((e["video"]["avg_views"] or 0) / fol) if fol else 0
    if _rr >= 1.5:
        A.append(("Make more short videos — they're working",
                  f"Your reels reach about {_rr:.1f}× your follower count — they're spreading well beyond your audience. Make more of what's working.", "Worth doing", "keep going"))
    if e["avg_comments"] < 1:
        A.append(("End your captions with a question",
                  "Hardly anyone comments right now. Asking something simple like \"Which one would you pick?\" gets people replying — and that helps more people see your post.", "Quick win", "1 min a post"))
    if not A:
        A.append(("Keep going — you're on the right track",
                  "Post regularly and make more of what already works well for you.", "Worth doing", "ongoing"))
    return A[:4]


def _plan(r):
    s, lc = r["snapshot"], r["lifecycle"]
    n0, n1, n2 = _biz_noun(s)
    if lc["closure_flag"]:
        rows = [("Mon", "Photos", "Thank you to everyone who visited"),
                ("Tue", "Reel", f'"Last week to visit" — show your favourite {n0}s'),
                ("Wed", "Story + Reel", "How to order from us after we close"),
                ("Thu", "Reel", "The team says a little goodbye"),
                ("Fri", "Photos", "Customer photos & happy memories"),
                ("Sat", "Reel", "Final weekend — come see us (with the link)"),
                ("Sun", "Photo", "A hint at what's coming next")]
    else:
        days = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"]
        topics = [("Reel", f"Show off your best {n0}"),
                  ("Photos", "A happy customer's words about you"),
                  ("Reel", "One quick, helpful tip"),
                  ("Photo", "A peek behind the scenes"),
                  ("Reel", 'This week\'s offer — with "Book now"'),
                  ("Story + Photo", f'Ask: "Which {n0} should we feature?"'),
                  ("Reel", "A fun, relatable moment")]
        rows = [(days[i], topics[i][0], topics[i][1]) for i in range(7)]
    return [{"day": d, "type": t, "topic": to} for d, t, to in rows]


def _working_well(r):
    s, e, c, f, cta = r["snapshot"], r["engagement"], r["consistency"], r["format"], r["cta"]
    fol = s["followers"] or 1
    W = []
    if e["er_pct"] >= 3:
        W.append("People really interact with your posts — more than most accounts your size.")
    if f["video_pct"] >= 60:
        W.append("You post lots of short videos — exactly the kind of post Instagram shows to the most people.")
    _ratio = (e["video"]["avg_views"] / fol) if (e["video"]["avg_views"] and fol) else 0
    if _ratio >= 1.3:
        W.append(f"Your reels reach beyond your followers — about {_ratio:.1f}× your follower count.")
    if c["label"] in ("Good", "Excellent"):
        W.append("You post regularly, which keeps you showing up in people's feeds.")
    if s["highlights"] and s["highlights"] >= 5:
        W.append(f"Your profile looks well set up, with {s['highlights']} story highlights.")
    if cta["strength"] in ("Moderate", "Strong"):
        W.append("You often tell people what to do next — that's what turns views into customers.")
    if e["top3"]:
        W.append(f"Your best post got {e['top3'][0]['eng']} likes and comments — a clear sign of what your audience loves.")
    return W[:6] or ["You've got an active page with a clear personality."]


def run_audit(business: dict) -> dict:
    """Full audit for one Apify profile object. Pure function, no I/O."""
    r = _metrics(business)
    if r.get("empty"):
        r["actions"] = [("We couldn't find recent posts",
                         "This account has no recent public posts to analyse. Make sure it's public and has posted recently.", "Big", "—")]
        r["plan"], r["working_well"] = [], []
        return r
    r["actions"] = _actions(r)
    r["plan"] = _plan(r)
    r["working_well"] = _working_well(r)
    return r
