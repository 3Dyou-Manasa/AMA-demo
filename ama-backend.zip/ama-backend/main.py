"""
AMA backend — FastAPI.

Endpoints
  GET  /audit?handle=kortyard.in   -> live: scrape via Apify, then audit
  POST /audit/raw                  -> testing: send a raw Apify profile JSON, get the audit
                                      (lets you test the full pipeline with no network/token)
  GET  /health                     -> liveness check

Run:
  pip install -r requirements.txt
  export APIFY_TOKEN=your_token_here     # only needed for the live /audit endpoint
  uvicorn main:app --reload
Then open http://127.0.0.1:8000/docs
"""
from fastapi import FastAPI, HTTPException, Body
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel

import engine
import apify_client
import samples

app = FastAPI(title="AMA — AI Marketing Assistant", version="0.1")

# allow the React dev server to call us (dev-friendly; tighten for production)
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)


@app.get("/health")
def health():
    return {"ok": True}


@app.get("/samples")
def samples_list():
    """List the 8 baked-in demo businesses (for the dropdown)."""
    return samples.list_samples()


@app.get("/audit/sample")
def audit_sample(handle: str):
    """Audit one of the baked-in demo businesses (no Apify/token needed)."""
    profile = samples.get_sample(handle)
    if profile is None:
        raise HTTPException(status_code=404, detail=f"No sample for @{handle}.")
    return engine.run_audit(profile)


@app.get("/audit")
async def audit(handle: str, posts: int = 30):
    """Live audit: scrape the handle via Apify, then run the engine."""
    try:
        profile = await apify_client.fetch_profile(handle, posts_limit=posts)
    except RuntimeError as e:
        raise HTTPException(status_code=502, detail=str(e))
    return engine.run_audit(profile)


@app.post("/audit/raw")
def audit_raw(profile: dict = Body(..., description="A raw Apify profile object (with latestPosts)")):
    """
    Test endpoint: paste a profile JSON straight from Apify and get the audit.
    Identical engine path as /audit — only the data source differs.
    Accepts either a single profile object or a list (uses the first item).
    """
    if isinstance(profile, list):
        if not profile:
            raise HTTPException(status_code=400, detail="Empty list.")
        profile = profile[0]
    if "latestPosts" not in profile:
        raise HTTPException(status_code=400,
                            detail="That doesn't look like an Apify 'details' profile object "
                                   "(no 'latestPosts'). Use resultsType='details'.")
    return engine.run_audit(profile)
