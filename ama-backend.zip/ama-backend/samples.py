"""
Bundled demo data: the 8 real businesses we analysed, so the app is fully
demo-able without an Apify token. Same engine path as live data.
"""
import json
import os

_PATH = os.path.join(os.path.dirname(__file__), "sample_data.json")

with open(_PATH, encoding="utf-8") as f:
    _SAMPLES = json.load(f)

# index by handle for quick lookup
_BY_HANDLE = {b.get("username"): b for b in _SAMPLES}


def list_samples():
    """Lightweight list for the dropdown."""
    out = []
    for b in _SAMPLES:
        cat = (b.get("businessCategoryName") or "").replace("None,", "").replace("None", "").strip(", ") or "Uncategorized"
        out.append({
            "handle": b.get("username"),
            "full_name": b.get("fullName"),
            "category": cat,
            "followers": b.get("followersCount"),
        })
    return out


def get_sample(handle: str):
    """Raw profile object for one handle, or None."""
    return _BY_HANDLE.get(handle)
